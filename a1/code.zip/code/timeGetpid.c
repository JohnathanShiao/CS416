#include <stdlib.h>
#include <stdio.h>

// Place any necessary global variables here

int main(int argc, char *argv[]){

	/*
	 *
	 * Implement Here
	 *
	 *
	 */

	return 0;

}
